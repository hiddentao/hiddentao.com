<?php
/*
TaoUtils wordpress plugin
Copyright (C) 2007-2009 Ramesh Nair

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/*
Plugin Name: TaoUtils
Plugin URI: http://www.hiddentao.com/code/wordpress-taoutils-plugin/
Description: Provides a number of useful utility methods for use in your PHP 
scripts (PHP 5+ only).
Version: 0.4
Author: Ramesh Nair
Author URI: http://www.hiddentao.com/
*/



/**
 * The main interface to the TaoUtils plugin.
 * 
 * You do not need to instantiate this class. Simply call the static methods.  
 */  
class TaoUtils
{
	/** 
	 * An internal cache for any type of object.
	 */
	private static $cache = array();


	/**
	 * Construct a HTML anchor tag for a given URL.
	 *
	 * @param $url 		the link URL.
	 * @param $text 	the link text.
	 * @param $title 	the link tooltip (optional).
	 * @param $rel 		the link relation type (optional).
	 * @param $accesskey 	the access key to assign to this link (optional).
	 * @param $target_frame		the link's target frame (optional).	 	 
	 * @return A fully constructed anchor tag.
	 */
	public static function construct_link($url, $text, $title='', $rel='', $accesskey='', $target_frame='_self')
	{
		return "<a href=\"$url\" title=\"$title\" rel=\"$rel\" accesskey=\"$accesskey\" target=\"$target_frame\">$text</a>";
	}



	/**
	 * Strip all single- and double-quotes from the given string.
	 * 
	 * @param $str the string to strip the quotes from.
	 * @return $str without any single- or double- quotes.
	 */	 	 	 	 
	public static function strip_quotes($str)
	{
		$str = str_replace('"', '', $str);
		return str_replace("'", '', $str);
	}






	/**
	 * Obfuscate an email address.
	 * 
	 * Note that this is a relatively trivial form of obfuscation which 
	 * performs the following replacements:
	 * 	 
	 * 		.  		is replaced by 		[dot]
	 * 			 
	 * 		@		is replaced by		[at]
	 * 	 
	 * Furthermore, random noise is added to the final output to further 
	 * discourage spam parsers.	 	  
	 * 
	 * @param $email_address the email address to obfuscate.
	 * @return Obfuscated version of $email_address.	 	 	 	 	 	 	 	 
	 */
	public static function obfuscate_email_address($email_address)
	{
		$ob = str_replace('@',' [at] ', $email_address);
		return TaoUtils::my_obfuscate(str_replace('.',' [dot] ', $ob));
	}



	
	/**
	 * Get a value from the object cache.
	 * 	 
	 * @param $key 		the key which uniquely identifies the value. This is 
	 * 					case-sensitive.	 
	 * @return 	  	the value if one exists for $key, otherwise NULL.
	 */ 
	public static function cache_get($key)
	{
		if (array_key_exists($key, TaoUtils::$cache))
			return TaoUtils::$cache[$key];
		else
			return NULL;
	}	
	
	
	/**
	 * Put a value into the object cache.
	 * 	 
	 * @param $key 		the key which uniquely identifies the value. This is 
	 * 					case-sensitive.	 
	 * @param $value 	the value to set.
	 * @return 			$value.	 
	 */ 
	public static function cache_set($key, $value)
	{
		TaoUtils::$cache[$key] = $value;
		return $value;
	}



	/**
	 * Get an obfuscated version of the given input text.
	 * 	 
	 * This will replace each character with its equivalent HTML character 
	 * code wrapped inside a <span> element.
	 *
	 * @param $input The input text.
	 * @param $addnoise Whether to add empty HTML tags to the output as noise.
	 * @return The obfuscated version of $input.
	 */
	private static function my_obfuscate($input, $addnoise=true)
	{
	  // obfuscate non-spaces
	  $matches = preg_match_all("/(\S|\s)/U", $input, $array, PREG_OFFSET_CAPTURE);
	
	  // reverse order since we're modifying source string as we go along
	  for ($i=$matches-1; $i>=0; --$i)  
	  {
	    $replacement = '<span>&#' . ord($array[0][$i][0]) . ';</span>';
	
	    if ($addnoise)
	    {
	      // random noise
	      $r = rand(0,10);
	      if ($r<3)
	        $replacement .= "<span id='a:bc$r-def-geh.zzz3$i'></span>";
	      elseif ($r<6)
	        $replacement .= "<span id='ab.aj-8225.4$r$i'></span>";
	      elseif ($r<9)
	        $replacement .= "<span id='a7321$r-8224:509$i-nbsp'></span>";
	    }
	
	    $input = substr_replace($input, $replacement, $array[0][$i][1], 1);
	  }
	
		return $input;
	}


}

 
?>