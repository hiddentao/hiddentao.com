TaoUtils
========
Version: 	 0.4
Homepage: 	 http://www.hiddentao.com/code/wordpress-taoutils-plugin/
Requires: 	 PHP 5, Wordpress 2.3
Tested upto: Wordpress 2.9


TaoUtils is a Wordpress plugin which provides you with a few general-purpose 
utility methods for use within your PHP scripts.


Full API documentation is available in the docs/ folder.



Changelog
=========

v0.4 (Apr 11, 2009)
--------------------
 * Improved the email obfuscator output

v0.3 (Jul 31, 2008)
--------------------
 * Added 'strip_quotes' method
 
v0.2 (Mar 31, 2008)
--------------------
 * Update README.txt
 * Made sure that the plugin works in Wordpress 2.5
  
v0.1 (Dec 2, 2007)
--------------------
 * Initial release
  
