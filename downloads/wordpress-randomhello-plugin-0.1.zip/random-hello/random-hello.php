<?php
/*
RandomHello wordpress plugin
Copyright (C) 2008-2009 Ramesh Nair

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/*
Plugin Name: RandomHello
Plugin URI: http://www.hiddentao.com/code/wordpress-randomhello-plugin/
Description: Provides methods to output 'Hello' in a random language.
Version: 0.1
Author: Ramesh Nair
Author URI: http://www.hiddentao.com/
*/



/**
 * The main interface to the RandomHello plugin.
 * 
 * You do not need to instantiate this class. Simply call the static methods.  
 */  
class RandomHello
{
	/**
	 * List of 'hello's.
	 * Data from http://www.wikihow.com/Say-Hello-in-Different-Languages	 	 
	 */
	private static $_Hellos = array(
		"Afrikaans" => "Haai",
		"Albanian" => "Tungjatjeta",
		"A'Leamona" => "Tél-nìdõ",
		"Armenian" => "Barev",
		"Azerbaijani" => "Salam",
		"Bremnian" => "Koali",
		"Bulgarian" => "Zdrasti",
		"Burmese" => "Mingalarbar",
		"Catalan" => "Hola",
		"Congo" => "Mambo",
		"Cree" => "Tansi",
		"Croatian" => "Bok",
		"Czech" => "Ahoj",
		"Dutch" => "Hoi",
		"English" => "Hello",
		"Fijian" => "Bula",
		"French" => "Bonjour",
		"Georgian" => "Gamardjoba",
		"Gujarathi" => "Kem-che",
		"Greek" => "Yia Sou",
		"Hawaiian" => "Aloha",
		"Hebrew" => "Shalom",
		"Hindi" => "Namaste",
		"Kannada" => "Namaskara",
		"Klingon" => "NuqneH?",
		"Latin" => "Salve",
		"Luxembourgish" => "Moïen",
		"Mandarin" => "Ni Hao",
		"Maori" => "Kia-ora",
		"Northern German" => "Moin Moin",
		"Scanian" => "Haja",
		"Senegal" => "Salamaleikum",
		"Swiss German" => "Grüzi",
		"Tamil" => "Vanakkam",
		"Telugu" => "Baagunnara",
		"Welsh" => "Shwmae",
		"Zulu" => "Sawubona"
	);


	/**
	 * Output 'hello' in a random language.
	 * 	 
	 * This outputs the following:
	 * 
	 * @code	 
	 *		<span title="'Hello' in [language name]">[Hello in language]</span>
	 * @endcode	 	 	 	 	 
	 */
	public static function hello()
	{
		$a = RandomHello::get_hello();
		echo "<span title=\"'Hello' in $a[0]\">$a[1]</span>"; 
	}
	
	
	/**
	 * Get 'hello' in a random language.
	 * 	 
	 * @return an array containing language name followed by the 'hello' word 
	 * in that language.	 
	 */	
	public static function get_hello()
	{
		$key = array_rand(RandomHello::$_Hellos);
		return array($key, RandomHello::$_Hellos[$key]);
	}



}

 
?>