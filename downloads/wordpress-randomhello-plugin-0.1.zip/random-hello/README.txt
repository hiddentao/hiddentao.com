RandomHello
========
Version: 	 0.1
Homepage: 	 http://www.hiddentao.com/code/wordpress-randomhello-plugin/
Requires: 	 PHP 5, Wordpress 2.3
Tested upto: Wordpress 2.9


RandomHello is a Wordpress plugin which provides methods to output 'Hello' in 
a random language.


Full API documentation is available in the docs/ folder.



Changelog
=========

v0.1 (Aug 7, 2008)
--------------------
 * Initial release
  
