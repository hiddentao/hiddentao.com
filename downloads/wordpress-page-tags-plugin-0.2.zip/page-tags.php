<?php
/*
Page-Tags wordpress plugin
Copyright (C) 2009 Ramesh Nair

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/*
Plugin Name: Page-Tags
Plugin URI: http://www.hiddentao.com/code/wordpress-page-tags-plugin/
Description: Enables tagging for pages.
Version: 0.2
Author: Ramesh Nair
Author URI: http://www.hiddentao.com/
*/


// name of my parent folder
define('PAGE_TAGS_PARENT_DIR', basename(dirname(__FILE__)) );


/**
 * The Page-Tags class. Handles everything.
 */ 
class PageTags
{
	function __construct()
	{
		// if we're editing or adding a page
		global $pagenow;
		if ( in_array( $pagenow, array('page.php', 'page-new.php') ) )
		{
			add_action('admin_head',array(&$this, 'admin_head_hook') );
			add_action('wp_default_scripts', array(&$this, 'setup_scripts'), 100 );
		}	
		add_action('pre_get_posts', array(&$this, 'setup_query_vars_for_posts'), 100);
		
		// override default tag count update callback
		$tax = get_taxonomy('post_tag');
		if ($tax)
		{
			$tax->update_count_callback = array(&$this, '_update_post_term_count');
		}
	}
	
	
	/**
	 * Set the Wordpress query variables (this determines what gets loaded 
	 * from the db).
	 */	 	
	function setup_query_vars_for_posts(&$query)
	{
		// if we're viewing tag archives
		if ($query->is_archive && $query->is_tag)
		{
			$q = &$query->query_vars;
			
			// set the post-type to 'any' so that pages are also included
			$q['post_type'] = 'any';
		}
	}
	
	
	
	
	/**
	 * Set the Javascript files that need to be included for this to work.
	 */	 	
	function setup_scripts(&$scripts)
	{
		// remove the default 'page' script definitions
		if ( $scripts->query('page') )
			$scripts->remove('page');

		//
		// Redo it, essentially copying what we have for 'post' handle 
		// (Taken from wp-includes/script-loader.php)
		//
		$scripts->add( 'page', WP_PLUGIN_URL.'/'.PAGE_TAGS_PARENT_DIR.'/page-tags.js', array('suggest', 'jquery', 'slug', 'wp-lists', 'postbox'), '20081210' );
		$scripts->localize( 'page', 'postL10n', array(
			'tagsUsed' =>  __('Tags used on this page:'),
			'add' => attribute_escape(__('Add')),
			'addTag' => attribute_escape(__('Add new tag')),
			'separate' => __('Separate tags with commas'),
			'cancel' => __('Cancel'),
			'edit' => __('Edit'),
			'publishOn' => __('Publish on:'),
			'publishOnFuture' =>  __('Schedule for:'),
			'publishOnPast' => __('Published on:'),
			'showcomm' => __('Show more comments'),
			'endcomm' => __('No more comments found.'),
			'publish' => __('Publish'),
			'schedule' => __('Schedule'),
			'update' => __('Update Page'),
			'savePending' => __('Save as Pending'),
			'saveDraft' => __('Save Draft'),
			'private' => __('Private'),
			'public' => __('Public'),
			'password' => __('Password Protected'),
			'privatelyPublished' => __('Privately Published'),
			'published' => __('Published'),
			'l10n_print_after' => 'try{convertEntities(postL10n);}catch(e){};'
		) );	
	}
	
	
	
	/**
	 * Display page tags form fields.
	 * 
	 * This is coped from wp-admin/edit-form-advanced.php.  
	 *
	 * @param object $post
	 */
	function add_tags_meta_box($post) 
	{
	?>
		<p id="jaxtag"><label class="hidden" for="newtag"><?php _e('Tags'); ?></label><input type="text" name="tags_input" class="tags-input" id="tags-input" size="40" tabindex="3" value="<?php echo get_tags_to_edit( $post->ID ); ?>" /></p>
		<div id="tagchecklist"></div>
		<p id="tagcloud-link" class="hide-if-no-js"><a href='#'><?php _e( 'Choose from the most popular tags' ); ?></a></p>
	<?php
	}
	
	
	/**
	 * Stuff to do for the 'admin_head' hook.
	 */ 
	function admin_head_hook()
	{
		// add our little Tag editing box
		add_meta_box('tagsdiv', __('Tags'), array(&$this, 'add_tags_meta_box'), 'page', 'side', 'default');
	}
	
	
	/**
	 * Custom version of the Wordpress taxonomy 'update term count' callback method.
	 * 
	 * This will update term count pased on posts AS WELL AS pages.
	 * @param array $terms List of Term taxonomy IDs
	 */
	function _update_post_term_count( $terms )
	{
		global $wpdb;
		foreach ( (array) $terms as $term ) {
			$count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $wpdb->term_relationships, $wpdb->posts WHERE $wpdb->posts.ID = $wpdb->term_relationships.object_id AND post_status = 'publish' AND (post_type = 'post' OR post_type = 'page') AND term_taxonomy_id = %d", $term ) );
			$wpdb->update( $wpdb->term_taxonomy, compact( 'count' ), array( 'term_taxonomy_id' => $term ) );
	}
}	
}





/**
 * Initialise PageTags object.
 */  
function init_page_tags()
{
	global $pageTags;
	$pageTags = new PageTags();
}


add_action('plugins_loaded','init_page_tags');


?>