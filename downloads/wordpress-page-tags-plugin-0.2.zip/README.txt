Page-Tags
============
Version: 	 0.2
Homepage: 	 http://www.hiddentao.com/code/wordpress-page-tags-plugin/
Requires: 	 PHP 5, Wordpress 2.7
Tested upto: Wordpress 2.7.1


Page-Tags is a Wordpress plugin which lets you tag your pages just like 
you do with your posts. It adds a tagging widget in the page-editing view 
in the admin interface.

