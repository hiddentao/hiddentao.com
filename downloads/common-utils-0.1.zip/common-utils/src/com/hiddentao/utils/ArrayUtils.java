/**
 * HiddenTao common-utils Java library
 * Copyright (C) 2010 Ramesh Nair (www.hiddentao.com)
 *
 * This is free software: you can redistribute it and/or modify it under the 
 * terms of the GNU Lesser General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This is distributed in the hope that it will  be useful, but WITHOUT ANY 
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
 * FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.hiddentao.utils;



/**
 * A collection of array uility methods.
 * 
 * @author Ramesh Nair
 */
public final class ArrayUtils
{
	private ArrayUtils() {}
	
	
	/**
	 * Get whether the given array contains the given element.
	 * 
	 * This uses a linear search of O(n) time complexity.
	 *  
	 * @param aHaystack the array to search.
	 * @param aNeedle the element to search for.
	 * @return true if so; false otherwise.
	 */
	public static boolean contains(int[] aHaystack, int aNeedle)
	{
		if (null == aHaystack)
		{
			return false;
		}
	
		for (int i=0; i<aHaystack.length; ++i)
		{
			if (aNeedle == aHaystack[i])
				return true;
		}
		
		return false;
	}
	
	
	/**
	 * Fill the given array with the given value.
	 * @param array the array to fill.
	 * @param fillValue the value to fill it with.
	 */
	public static void fill(int[] array, final int fillValue)
	{
		for (int i=0; i<array.length; ++i)
		{
			array[i] = fillValue;
		}
	}
}
