/**
 * HiddenTao common-utils Java library
 * Copyright (C) 2010 Ramesh Nair (www.hiddentao.com)
 *
 * This is free software: you can redistribute it and/or modify it under the 
 * terms of the GNU Lesser General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This is distributed in the hope that it will  be useful, but WITHOUT ANY 
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
 * FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this.  If not, see <http://www.gnu.org/licenses/>.
 */
package javax.swing.applet;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;



/**
 * Applet environment simulator which allows you to execute a {@link JAbstractApplet} as a standalone Java application.
 * 
 * This will take care of creating and initialising and the 
 * {@link JAbstractApplet}.
 * 
 * @author Ramesh Nair
 */
public final class JAppletSimulator
{
    private static final String LOG_PREFIX = "[JApplet Simulator] ";
    
    private static JAppletSimulator iInstance = null;

    /**
     * The runtime class of the applet instance.
     */
    private Class iAppletClass = null;
    
    /**
     * The runtime {@link JAbstractApplet} instance.
     */
    private JAbstractApplet iAppletInstance = null;
    
    /**
     * Flag which indicates whether the simulator is running or not.
     */
    private boolean iSimulatorIsRunning = false;
    
    /**
     * The runtime simulated applet instance.
     */
    private JSimulatedAppletImpl iSimAppletImpl = null; 
    
    
    static JAppletSimulator getInstance()
    {
        if (null == iInstance)
        {
            iInstance = new JAppletSimulator();
        }
        return iInstance;
    }
    
    private JAppletSimulator() {}
    
    /**
     * Initialise the applet simulator.
     * @param aCommandLineArgs the command-line parameters.
     */
    private void init(String[] aCommandLineArgs)
    {
        iSimulatorIsRunning = true;
        
        // create app. window
        iSimAppletImpl = new JSimulatedAppletImpl();
        iSimAppletImpl.addWindowListener( iAppletWindowCallbackHandler );
        
        // process command-line args
        processCommandLineArguments( aCommandLineArgs );
        
        // construct and initialise
        try
        {
            iAppletInstance = (JAbstractApplet)iAppletClass.newInstance();
            
            // init
            logInfoMsg("Applet.init ...");
            iSimAppletImpl.setAppletIsActive( false );
            iAppletInstance.init();

            // centre on screen
    		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    		Dimension windowSize = iSimAppletImpl.getSize();
    		iSimAppletImpl.setLocation((screenSize.width - windowSize.width)/2, (screenSize.height - windowSize.height)/2);
            
            // display window
            iSimAppletImpl.setVisible( true );
            
            // start
            logInfoMsg("Applet.start ...");
            iSimAppletImpl.setAppletIsActive( true );
            iAppletInstance.start();
        }
        catch( Exception e )
        {
            logErrorMsg("Error during applet initialisation...");
            e.printStackTrace(System.err);
            System.exit(-1);
        }
    }
    
    
    
    /**
     * Program entry-point.
     * 
     * @param args first argument should be the fully-qualified name of 
     * {@link JAbstractApplet}-derived class.
     */
    public static void main(String[] args)
    {
        getInstance().init( args );
        
    }
    
    
    private static void printUsageAndExit()
    {
        logErrorMsg("Usage:");
        logErrorMsg("\tjava " + JAppletSimulator.class.getName() + " <a.b.c.d.SomeClass> <codebase_path> <width> <height> [<param1>=<value1>] [<param2=value2>] ...");
        logErrorMsg("\nRequired parameters:\n");
        logErrorMsg("a.b.c.d.SomeClass  - fully-qualified name of class derived from " + JAbstractApplet.class.getName());
        logErrorMsg("codebase_path      - fully-qualified path to folder containing applet JAR files");
        logErrorMsg("width              - initial width (in pixels) of applet window");
        logErrorMsg("height             - initial height (in pixels) of applet window");
        logErrorMsg("paramX=valueX      - OPTIONAL. One or more name-value pairs to pass through as applet parameters. Any internal whitespace gets automatically removed.");
        System.exit( -1 );        
    }
    
    
    /**
     * Process all the command-line arguments.
     * @param args the command-line arguments.
     */
    private void processCommandLineArguments(String[] args)
    {
        if (args.length < 4)
        {
            printUsageAndExit();
        }
        
        logInfoMsg("BEGIN processing command-line arguments");
        
        try
        {
            iAppletClass = Class.forName( args[0] );
            logInfoMsg("Class: " + iAppletClass.getName());
            
            iSimAppletImpl.setAppletCodeBase(new File(args[1]).toURI().toURL());
            logInfoMsg("Codebase: " + iSimAppletImpl.getAppletCodeBase());
            
            // get dimensions
            int width = Integer.parseInt( args[2] );
            int height = Integer.parseInt( args[3] );
            iSimAppletImpl.setSize( width, height );
            logInfoMsg("Size: " + width + " * " + height + " px");
            
            // get applet parameters
            for (int i=4; i<args.length; ++i)
            {
                String[] tokens = args[i].replaceAll( "\\s+", "" ).split( "=" );
                if (tokens.length<2 || tokens[0].length()<1 || tokens[1].length()<1)
                {
                    throw new Exception("Expected format: <name>=<value> for '" + args[i] + "'");
                }
                
                iSimAppletImpl.setAppletParameter( tokens[0], tokens[1] );
                logInfoMsg("Param: '" + tokens[0] + "' = '" + tokens[1] + "'");
            }
        }
        catch( Exception e )
        {
            e.printStackTrace(System.err);
            printUsageAndExit();
        }
        
        logInfoMsg("END processing command-line arguments");
    }
    
    
    
    /**
     * Get whether the applet simulator is currently running.
     * @return true if so; false otherwise.
     */
    boolean isSimulatorRunning()
    {
        return iSimulatorIsRunning;
    }

    
    /**
     * Get the object to which all 
     * {@link JAbstractApplet} calls should be delegated.
     */
    JSimulatedAppletImpl getSimulatedAppletImpl()
    {
        return iSimAppletImpl;
    }

    
    /**
     * Output an information message to {@link System#out}.
     * @param msg the message to output.
     */
    static void logInfoMsg(String msg)
    {
        System.out.println(LOG_PREFIX + msg);
    }
    
    /**
     * Output an error message to {@link System#err}.
     * @param msg the message to output.
     */
    static void logErrorMsg(String msg)
    {
        System.err.println(LOG_PREFIX + msg);
    }
    
    
    
    /**
     * Watch for changes to the application window.
     */
    private WindowAdapter iAppletWindowCallbackHandler = new WindowAdapter() 
    {
        public void windowClosing( WindowEvent e )
        {
            try
            {
            	// destroy the applet
                iSimAppletImpl.setAppletIsActive( false );
                iAppletInstance.stop();
                iAppletInstance.destroy();
                logInfoMsg("Shutdown was clean.");
                System.exit( 0 );
            }
            catch (Exception exc)
            {
                logErrorMsg("Error during shutdown...");
                exc.printStackTrace(System.err);
                System.exit(-1);
            }
        }
    };
   
    
}


