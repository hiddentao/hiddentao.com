/**
 * HiddenTao common-utils Java library
 * Copyright (C) 2010 Ramesh Nair (www.hiddentao.com)
 *
 * This is free software: you can redistribute it and/or modify it under the 
 * terms of the GNU Lesser General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This is distributed in the hope that it will  be useful, but WITHOUT ANY 
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
 * FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this.  If not, see <http://www.gnu.org/licenses/>.
 */
package javax.swing.applet;


import java.applet.AppletContext;
import java.applet.AudioClip;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.Image;
import java.net.URL;
import java.util.Locale;

import javax.swing.JApplet;


/**
 * The base class for all applets which can either be run in a browser or 
 * through {@link JAppletSimulator}.
 * 
 * @author Ramesh Nair
 */
public abstract class JAbstractApplet extends JApplet
{
    /**
     * Instance of the simulated applet implementation.
     */
    private JSimulatedAppletImpl iSimAppletImpl = null;
    
    
    public JAbstractApplet() throws HeadlessException
    {
        super();
        
        if (JAppletSimulator.getInstance().isSimulatorRunning())
        {
            iSimAppletImpl = JAppletSimulator.getInstance().getSimulatedAppletImpl();
        }
    }
    
    

    /**
     * Refresh this applet's GUI and repaint its components.
     */
    public void refreshGui()
    {
        if (null != iSimAppletImpl)
        {
            iSimAppletImpl.refreshAppletGui();
        }
        else
        {
            getContentPane().validate();
            repaint();
        }
    }

    
    public Container getContentPane()
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getContentPane();
        }
        else
        {
            return super.getContentPane();
        }        
    }
    
    
    public AppletContext getAppletContext()
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletContext();
        }
        else
        {
            return super.getAppletContext();
        }
    }

    public String getAppletInfo()
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletInfo();
        }
        else
        {
            return super.getAppletInfo();
        }
    }

    public AudioClip getAudioClip( URL url, String name )
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletAudioClip(url,name);
        }
        else
        {
            return super.getAudioClip(url,name);
        }
    }

    public AudioClip getAudioClip( URL url )
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletAudioClip(url);
        }
        else
        {
            return super.getAudioClip(url);
        }
    }

    public URL getCodeBase()
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletCodeBase();
        }
        else
        {
            return super.getCodeBase();
        }
    }

    public URL getDocumentBase()
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletDocumentBase();
        }
        else
        {
            return super.getDocumentBase();
        }
    }

    public Image getImage( URL url, String name )
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletImage( url, name );
        }
        else
        {
            return super.getImage(url, name);
        }
    }

    public Image getImage( URL url )
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletImage( url );
        }
        else
        {
            return super.getImage(url);
        }
    }

    public Locale getLocale()
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletLocale();
        }
        else
        {
            return super.getLocale();
        }
    }

    public String getParameter( String name )
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletParameter(name);
        }
        else
        {
            return super.getParameter(name);
        }
    }

    public String[][] getParameterInfo()
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.getAppletParameterInfo();
        }
        else
        {
            return super.getParameterInfo();
        }
    }

    public boolean isActive()
    {
        if (null != iSimAppletImpl)
        {
            return iSimAppletImpl.isAppletActive();
        }
        else
        {
            return super.isActive();
        }
    }

    public void play( URL url, String name )
    {
        if (null != iSimAppletImpl)
        {
            iSimAppletImpl.playAppletSound(url, name);
        }
        else
        {
            super.play(url, name);
        }
    }

    public void play( URL url )
    {
        if (null != iSimAppletImpl)
        {
            iSimAppletImpl.playAppletSound(url);
        }
        else
        {
            super.play(url);
        }
    }

    public void resize( Dimension d )
    {
        if (null != iSimAppletImpl)
        {
            iSimAppletImpl.resizeApplet(d);
        }
        else
        {
            super.resize(d);
        }
    }

    public void resize( int width, int height )
    {
        if (null != iSimAppletImpl)
        {
            iSimAppletImpl.resizeApplet(width,height);
        }
        else
        {
            super.resize(width,height);
        }
    }

    public void showStatus( String msg )
    {
        if (null != iSimAppletImpl)
        {
            iSimAppletImpl.showAppletStatus(msg);
        }
        else
        {
            super.showStatus(msg);
        }
    }


    public void destroy()
    {
        if (null == iSimAppletImpl)
        {
            super.destroy();
        }        
    }


    public void init()
    {
        if (null == iSimAppletImpl)
        {
            super.init();
        }        
    }


    public void start()
    {
        if (null == iSimAppletImpl)
        {
            super.start();
        }        
    }


    public void stop()
    {
        if (null == iSimAppletImpl)
        {
            super.stop();
        }        
    }
    
    
}


