=== Page Tagger ===

Contributors: randomaniac
Donate link: http://www.hiddentao.com/code/wordpress-page-tagger-plugin/
Tags: tags, tagging, posts, pages
Requires at least: 2.8.4
Tested up to: 2.8.6
Stable tag: 0.3.2

Page Tagger is a Wordpress plugin which lets you tag your pages just like you do with your posts. It adds a tagging widget in the page-editing view in the admin interface.

== Description ==

Page Tagger is a Wordpress plugin which lets you tag your pages just like you do with your posts. It adds a tagging widget in the page-editing view in the admin interface.

Detailed information including installation and usage is available at http://www.hiddentao.com/code/wordpress-page-tagger-plugin/ 

== Installation ==

1. Download and unzip the zip file into your Wordpress `plugins` folder such that the plugin files are at: `wp-content/plugins/page-tagger/...`
1. Activate the plugin within your blog's administration options.
1. All done!

== Changelog ==

= 0.3.2 =
* Fixed plugin conflict issue which was sometimes causing the tag editing interface to stop working.

= 0.3.1 =
* Plugin renamed to 'Page Tagger'. 

= 0.3 =
* Plugin now works in Wordpress 2.8+.
* *If your page tags were no longer showing in tag clouds then you need to upgrade to this version (0.3) and then [follow instructions to restore the correct post counts for each tag](http://www.hiddentao.com/archives/2009/09/08/page-tags-0-3/).* 
   
= 0.2 =
* Fixed a bug which was preventing tags added whilst editing pages from appearing in the tag cloud widget.
   
= 0.1 =
* The initial release.


== Known Issues ==

* None at the moment.
