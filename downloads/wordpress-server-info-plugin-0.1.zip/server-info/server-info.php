<?php
/*
Server-Info wordpress plugin
Copyright (C) 2009 Ramesh Nair

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/*
Plugin Name: Server-Info
Plugin URI: http://www.hiddentao.com/code/wordpress-server-info-plugin/
Description: Displays identifying information about the web server on every admin (and optionally, blog) page.
Version: 0.1
Author: Ramesh Nair
Author URI: http://www.hiddentao.com/
*/



class ServerInfo
{
	/**
	 * Define the constants we'll nee. 
	 */
	private function define_constants()
	{
		if (!defined('SERVER_INFO'))
		{
			define('SERVER_INFO', php_uname('n') . ' (' . $_SERVER['SERVER_ADDR'] . ')');
			define('SERVER_INFO_PLUGIN_DIR', basename(dirname(__FILE__)) );
			define('SERVER_INFO_OPTION_SUBMIT_BUTTON', 'server_info_submit_button');
			define('SERVER_INFO_OPTION_SHOW_BLOG_PARAM', 'server_info_showblog');
			define('SERVER_INFO_OPTION_SHOW_BLOG_VAL_NEVER', 'server_info_showblog_never');
			define('SERVER_INFO_OPTION_SHOW_BLOG_VAL_LOGGED_IN', 'server_info_showblog_logged_in');
			define('SERVER_INFO_OPTION_SHOW_BLOG_VAL_ALWAYS', 'server_info_showblog_always');
			define('SERVER_INFO_OPTION_SHOW_BLOG_EXCLUDE_IPS_PARAM', 'server_info_showblog_exclude_ips');
		}
	}
	
	/**
	 * Constructor.
	 * This sets up necessary hooks and filters.
	 */
	public function __construct()
	{
		$this->define_constants();
		
		add_action('admin_menu',array(&$this,'register_admin_options') );
		add_action('admin_head', array(&$this, 'show_server_info_admin') );
		add_action('wp_head',array(&$this, 'show_server_info_blog'));
	}
	
	/**
	 * Callback: Show the server information on an admin page.
	 */
	public function show_server_info_admin()
	{
		$this->_show_server_info();
	}
	
	/**
	 * Callback: Show the server information on a blog (non-admin) page.
	 */
	public function show_server_info_blog()
	{
		$show_on_blog = $this->get_show_blog_option();
		if (SERVER_INFO_OPTION_SHOW_BLOG_VAL_NEVER != $show_on_blog)
		{
			// if server is not in excluded list
			$excluded_ips = $this->get_excluded_ip_addresses();
			if (FALSE === strpos($excluded_ips, $_SERVER['SERVER_ADDR']) )
			{
				// if user needs to be logged in
				if (SERVER_INFO_OPTION_SHOW_BLOG_VAL_LOGGED_IN == $show_on_blog)
				{
					$current_user = wp_get_current_user(); 
					if (!isset($current_user) || 0 == $current_user->ID)
						return false;
				}
				
				// show it!
				$this->_show_server_info();
			}
		}
	}
	
	/**
	 * Show the server information on the current page.
	 */
	private function _show_server_info()
	{
		?>
		<link rel="stylesheet" href="<?php echo plugins_url(SERVER_INFO_PLUGIN_DIR.'/server-info.css'); ?>" type="text/css" media="all" />
		
		<script type="text/javascript">
		function makeDoubleDelegate(function1, function2)
		{
		    return function()
		    {
		        if (function1)
		            function1();
		        if (function2)
		            function2();
		    }
		}
		
		function showServerInfo() 
		{
			// show machine info in a flaoting green bar at the top of the page
			var oDiv=document.createElement("DIV");
			oDiv.setAttribute("id","server-info-bar");
			var oTxt = document.createTextNode("<?php echo SERVER_INFO; ?>");
			oDiv.appendChild(oTxt);
			document.body.appendChild(oDiv);
		}
		
		window.onload = makeDoubleDelegate(window.onload, showServerInfo )	
		</script>
		<?php 
	}	
	
	
	/**
	 * Register the administration options page.
	 */
	public function register_admin_options()
	{
		add_options_page('Server-Info Options', 'Server-Info', 9, 'server-info.php', array(&$this, 'admin_options'));
	}


	/**
	 * Render the administration options form and handle its submission.
	 */
	public function admin_options()
	{
		if($_POST[SERVER_INFO_OPTION_SUBMIT_BUTTON])
	  	{	
			update_option(SERVER_INFO_OPTION_SHOW_BLOG_EXCLUDE_IPS_PARAM, $_POST[SERVER_INFO_OPTION_SHOW_BLOG_EXCLUDE_IPS_PARAM]);
			update_option(SERVER_INFO_OPTION_SHOW_BLOG_PARAM, $_POST[SERVER_INFO_OPTION_SHOW_BLOG_PARAM]);
			echo '<div class="updated"><p>Options updated successfully.</p></div>';
		}
	
		$show_on_blog = $this->get_show_blog_option();
		$excluded_ip_addresses = $this->get_excluded_ip_addresses();
		
		?>
		<div class="wrap">
		<h2>Server-Info Options</h2>
	
		<form method="post" id="server_info_options">
	
			<p>Note: server information will always be shown when viewing administration pages.</p>

			<h3>Show on blog pages</h3>

			<fieldset>
			<p><input type="radio" name="<?php echo SERVER_INFO_OPTION_SHOW_BLOG_PARAM; ?>" value="<?php echo SERVER_INFO_OPTION_SHOW_BLOG_VAL_NEVER; ?>" <?php echo (SERVER_INFO_OPTION_SHOW_BLOG_VAL_NEVER==$show_on_blog?'checked="checked"':''); ?> > Never.</p>
			<p><input type="radio" name="<?php echo SERVER_INFO_OPTION_SHOW_BLOG_PARAM; ?>" value="<?php echo SERVER_INFO_OPTION_SHOW_BLOG_VAL_LOGGED_IN; ?>" <?php echo (SERVER_INFO_OPTION_SHOW_BLOG_VAL_LOGGED_IN==$show_on_blog?'checked="checked"':''); ?>> Only when logged in.</p>
			<p><input type="radio" name="<?php echo SERVER_INFO_OPTION_SHOW_BLOG_PARAM; ?>" value="<?php echo SERVER_INFO_OPTION_SHOW_BLOG_VAL_ALWAYS; ?>" <?php echo (SERVER_INFO_OPTION_SHOW_BLOG_VAL_ALWAYS==$show_on_blog?'checked="checked"':''); ?>> Always.</p>
			</fieldset>
			<p>
			<label for="<?php echo SERVER_INFO_OPTION_SHOW_BLOG_EXCLUDE_IPS_PARAM; ?>">Do NOT show on blog pages if server IP address is in the following list (this overrides the above options): </label>
			<br /><input type="text" name="<?php echo SERVER_INFO_OPTION_SHOW_BLOG_EXCLUDE_IPS_PARAM; ?>" value="<?php echo $excluded_ip_addresses; ?>" size="40" maxlength="64" /><em> (separate using commas, e.g. "1.2.3.4, 4.5.5.1")</em>
			</p>
			<p class="submit"><input type="submit" name="<?php echo SERVER_INFO_OPTION_SUBMIT_BUTTON; ?>" title="Save changes" value="Save Changes" /></p>
	
		</form>
		
		</div>
		<?php
	}
	
	/**
	 * Get the value of the 'show on blog' admin option.
	 * @return one of the SERVER_INFO_OPTION_SHOW_BLOG_VAL... values.
	 */
	private function get_show_blog_option()
	{
		$opt = get_option(SERVER_INFO_OPTION_SHOW_BLOG_PARAM);
		if (!$opt)
		{
			$opt = SERVER_INFO_OPTION_SHOW_BLOG_VAL_NEVER;
		}		
		return $opt;
	}
	
	
	/**
	 * Get the value of the 'excluded IP addresses' admin option.
	 * @return a string.
	 */
	private function get_excluded_ip_addresses()
	{
		$opt = get_option(SERVER_INFO_OPTION_SHOW_BLOG_EXCLUDE_IPS_PARAM);
		if (!$opt)
		{
			$opt = '';
		}		
		return $opt;
	}	
}



$server_info = new ServerInfo();
?>