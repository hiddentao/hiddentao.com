Server-Info
============
Version: 	 0.1
Homepage: 	 http://www.hiddentao.com/code/wordpress-server-info-plugin/
Requires: 	 PHP 5, Wordpress 2.7
Tested upto: Wordpress 2.9


Server-Info is a Wordpress plugin which displays information about the web 
server hosting your Wordpress installation on all administration 
(and optionally, blog) pages. Specifically it displays the hostname and 
IP address of the server.

When the plugin is successfully enabled then you should a little, 
floating green box in the top-left-hand corner when viewing your blog 
administration pages. In the administration options for the plugin you can 
set it to show on blog pages too, with the ability to restrict this 
to e.g. when the user is logged in.

You can customise the look and layout of the actual information box by 
editing server-info.css.


Changelog
=========

v0.1 (Mar 30, 2009)
--------------------
 * Initial release
