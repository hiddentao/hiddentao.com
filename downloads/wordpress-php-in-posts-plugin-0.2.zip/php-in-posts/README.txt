PHP-in-Posts
============
Version: 	 0.2
Homepage: 	 http://www.hiddentao.com/code/wordpress-php-in-posts-plugin/
Requires: 	 Wordpress 2.3
Tested upto: Wordpress 2.9


PHP-in-Posts is a Wordpress plugin which allows you to include PHP code 
within your blog entries - this includes blog posts, comments and pages. 
The PHP code gets executed and the resulting output (if any) gets included in 
the post's content.

On the plugin options page you can specify the minimum user permission 
level required in order to use PHP code within a post.




Changelog
=========

v0.2 (Mar 31, 2008)
--------------------
 * Update README.txt
 * Made sure that the plugin works in Wordpress 2.5
  
v0.1 (Dec 2, 2007)
--------------------
 * Initial release
