<?php
/*
PHP-in-Posts wordpress plugin
Copyright (C) 2007-2009 Ramesh Nair

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

/*
Plugin Name: PHP-in-Posts
Plugin URI: http://www.hiddentao.com/code/wordpress-php-in-posts-plugin/
Description: This plugin lets you execute PHP code inside blog entries.
Version: 0.2
Author: Ramesh Nair
Author URI: http://www.hiddentao.com/

Based on PHPExec plugin by Priyadi Iman
http://priyadi.net/archives/2005/03/02/wordpress-php-exec-plugin/
*/


define(PHP_IN_POSTS_ADMIN_OPTION_NAME, 'php_in_posts_userlevel');


/**
 * Do the PHP-in-Posts magic!
 */	  	
function php_in_posts_process($_inputText)
{
	$output = $_inputText;
	
	// check that post author has enough privileges to execute code
	$userdata = get_userdatabylogin(get_the_author_login());
	if ($userdata->user_level < php_in_posts_getuserlevel())
	{
		return $output;
	}
	
	
	/**
	 * 1.  Find and replace all echo expressions
	 */	 
	$vars_count = 
		preg_match_all(
			"/\[php\:(.+)\]/U", 
			$_inputText, 
			$vars, 
			PREG_PATTERN_ORDER | PREG_OFFSET_CAPTURE);

	// replace in reverse order because each time we replace something we affect
	// the length of the string.
	for ($i = $vars_count-1; $i >= 0; --$i)
  	{
    	$matchstring = $vars[0][$i][0];
    	$offset = $vars[0][$i][1];
    	$varname = $vars[1][$i][0];
    	
    	// if constant
    	if (defined($varname))
    	{
			$result = constant($varname);
		}
    	// else if variable
		else if (isset($varname))
		{
			// split on classname
			$pos = strpos($varname,'->');
			if (FALSE !== $pos)
			{
				$objname = substr($varname,0,$pos);
			}
			else
			{
				$objname = $varname;
			}
			ob_start();
			eval("global $objname; echo $varname;");
    		$result = ob_get_clean();
		}
		else
		{
			continue;
		}
		
    	$_inputText = substr_replace(
				$_inputText, $result, $offset, strlen($matchstring)
		);
	}
	
	/**
	 * 2. Execute embedded PHP code
	 */	 
	$phpip_execs_count = 
		preg_match_all(
			"/\[(php)\](.+)\[\/\\1\]/Us", 
			$_inputText, 
			$execs, 
			PREG_PATTERN_ORDER | PREG_OFFSET_CAPTURE);
	
	
	for ($i = $phpip_execs_count-1; $i >= 0; --$i)
  	{
	    $matchstring = $execs[0][$i][0];
	    $offset = $execs[0][$i][1];
	    $code = $execs[2][$i][0];
	    // execute the code
		ob_start();
		eval("$code");
		$result = ob_get_clean();
	    // replace
	    $_inputText = substr_replace(
			$_inputText, $result, $offset, strlen($matchstring)
		);
	}
	
	
	return $_inputText;	
}



/**
 * Add admin options page.
 */
function php_in_posts_do_admin_options()
{
	add_options_page('PHP-in-Posts Options', 'PHP-in-Posts', 9, 'php_in_posts.php', 'php_in_posts_options');
}



/**
 * Process admin options page.
 */
function php_in_posts_options()
{
	if($_POST['php_in_posts_save'])
  	{	
		update_option(PHP_IN_POSTS_ADMIN_OPTION_NAME, $_POST['php_in_posts_userlevel']);
		echo '<div class="updated"><p>Minimum user level saved successfully.</p></div>';
	}

	?>
	<div class="wrap">
	<h2>PHP-in-Posts Options</h2>

	<form method="post" id="php_in_posts_options">
	<fieldset class="options">

	<table class="optiontable"> 
		<tbody>
			<tr valign="top"> 
				<th scope="row">Minimum user level:</th> 
				<td>
					<input type="text" name="php_in_posts_userlevel" 
						id="php_in_posts_userlevel" value="<?php echo php_in_posts_getuserlevel(); ?>" size="2" class="code" maxlength="2"/>
					<br />
					Enter the minimum user level required to use PHP code in 
					their entries. Here are the equivalent levels for the 
					currently available user roles: 
					<p>
					<?php
					$a = php_in_posts_get_available_roles_and_their_levels();
					foreach ($a as $name => $level)
					{
						echo $name . " = " . $level . '<br />'; 
					}
					?>
					</p>
				</td>						
			</tr>
		</tbody>
	</table> 

	<p class="submit"><input type="submit" name="php_in_posts_save" 
							title="Save changes" value="Save Changes" /></p>

	</fieldset>
	</form>
	
	</div>
	<?php
}


/**
 * Get minimum user level required to use PHP code in posts
 */  
function php_in_posts_getuserlevel()
{
	if($level = get_option(PHP_IN_POSTS_ADMIN_OPTION_NAME))
		return $level;
	else
	{
		$a = php_in_posts_get_available_roles_and_their_levels();
		sort($a);
		// the last item is the one we want
		return end($a);
	}
}


/**
 * Get the available user roles and their corresponding levels.
 */ 
function php_in_posts_get_available_roles_and_their_levels()
{
	global $wp_roles;
	$dummyuser = new WP_User(0);

	$ret = array();
	
	if (NULL != $wp_roles)
	{
		foreach( $wp_roles->role_names as $role => $name )
		{
			$level = array_reduce(
					array_keys($wp_roles->get_role($role)->capabilities), 	
					array(&$dummyuser, 'level_reduction'), 
					0
			);
		
			$ret[$name] = $level;
		}
	}
	else
	{
		$ret[0] = 0;
	}
	
	return $ret;
}





add_action('admin_menu','php_in_posts_do_admin_options',1);
add_filter('the_content', 'php_in_posts_process', 2);
add_filter('the_excerpt', 'php_in_posts_process', 2);

?>