<?php
/**
 * Output the list of pages which match the archive query.
 */
 
 
if (!isset($list_of_pages))
{
	require_once('archive_results.php');
	return;
}

if (count($list_of_pages) < 1)
{
	echo '<em>No pages found.</em>';
	return;
}


$first_page = true;


foreach ($list_of_pages as $current_page) :
  
  	global $post;
  	$post = $current_page;
  	setup_postdata($post);
    
	$permalink_url = get_permalink();
	
	if ($first_page)
	{
		$first_page = false;
		echo '<ul class="linklist">';
	}
?>
			<li class="page">
				<span>
	        		<a href="<?php echo $permalink_url; ?>" title="Goto page" rel="bookmark"><?php the_title('',''); ?></a>
	      		</span>
			</li>
<?php

endforeach; 

if (!$first_page)
{
	echo '</ul>';
}

?>
