<?php
/**
 * This file is called by wordpress engine to display pages
 */ 

// Override the default placeholder content for certain pages
if ('archives' == SITE_SECTION)
{
	require_once('archive.php');
	exit;
}


get_header(); 
?>

<div id="content">
<a name="content" class="invisible">&para;</a>


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

	<div class="post singlepage staticpage">
	
	<h1 class="title"><?php the_title(); ?></h1>
	
		<div class="body">
			<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
			<div class="floatspacer"></div>
			<?php link_pages('<p><strong>Pages:</strong> ', '</p>', 'number'); ?>
		</div>

		<br />
		<?php edit_post_link('(edit this page)', '<p>', '</p>'); ?>
		
	</div>

<?php endwhile; endif; ?>

	<div class="floatspacer"></div>

</div> <!-- end #content -->

<?php get_sidebar(); ?>


<?php get_footer(); ?>
