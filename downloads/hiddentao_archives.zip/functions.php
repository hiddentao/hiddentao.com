<?php
/**
 * Class to hold commonly used strings
 */
class MyStrings
{
	function MyStrings()
	{
		$this->str_view_post_feedback = 'View comments and pings for this post';
		$this->str_read_fullpost = 'Read full post';
		$this->str_permalink = 'Permanent link to this post';
		$this->str_view_newer_posts = 'View newer posts';
		$this->str_view_older_posts = 'View older posts';
	}
}
$myStrings = new MyStrings();



// ------------------------------------------------------------------
// Work out which top-level site section we're in
// ------------------------------------------------------------------


$all_site_sections = array(
	array('path' => '', 'title' => 'Home', 'tooltip' => 'Homepage', 'rel' => 'home', 'accesskey' => '1'),
	array('path' => 'blog', 'title' => 'Blog', 'tooltip' => 'Latest blog posts'),
	array('path' => 'code', 'title' => 'Code', 'tooltip' => 'Useful software'),
	array('path' => 'portfolio', 'title' => 'Portfolio', 'tooltip' => 'Professional portfolio'),
	array('path' => 'archives', 'title' => 'Archives', 'tooltip' => 'Site archives'),
	array('path' => 'about', 'title' => 'About', 'tooltip' => 'About'),
);



$site_section = strtolower(trim($_SERVER['REQUEST_URI'],'/'));

// remove root folder
require_once(dirname(__FILE__).'/../../../wp-config.php');
if (defined('WP_ROOT_FOLDER'))
{
	$site_section = trim(substr($site_section, strlen(WP_ROOT_FOLDER)), '/');
}

// remove paging
$pos = strpos($site_section, 'page/');
if (FALSE !== $pos)
{
	$site_section = substr($site_section, 0, $pos);
}

// want highest-level folder only
$pos = strpos($site_section, '/');

// if <something>/<lower levels>
if (FALSE !== $pos)
{
	$site_section = substr($site_section, 0, $pos);
}
// else if just <something>
else
{
	$pos = strpos($site_section, '.');
	// if <one word>.<some extension>
	if (FALSE !== $pos)
	{
		$site_section = substr($site_section, 0, $pos);
	}
}

// have we got a valid site section or we trying to access a non-existent page?
foreach($all_site_sections as $arr)
{
	if ($arr['path'] == $site_section)
	{
		define('SITE_SECTION', $arr['path']);
		define('SUGGESTED_PAGE_TITLE', $arr['title']);	
		break;
	}
}
if (!defined('SITE_SECTION'))
{
	define('SITE_SECTION', 'ERROR-404');
	define('SUGGESTED_PAGE_TITLE', 'Page Not Found');	
}



?>
