<?php
/**
 * This file is called by wordpress engine to display archives pages
 */ 

/* get query variables */
global $wp_query;
$qry_tag_name = $wp_query->query_vars['tag'];
if ('' != $qry_tag_name)
{
	require_once('archive_results.php');
	exit;
}
else
{
	get_header(); 
}

?>


<div id="content">
<a name="content" class="invisible">&para;</a>
                         

<div id="archives">

	<h1 class="title">Archives</h1>

	<div id="tags">
		<p class="description">A <em>cloud</em> of all blog post tags in alphabetical order:</p>
		<div id="tagcloud">
			<?php wp_tag_cloud(array('number'=>70)); ?>
			<div class="floatspacer"></div>
		</div>
	</div>			
	

	<div id="all_results">
		<p class="description">The complete list of blog posts, from newest to oldest:</p>

    <div class="indented">

	<?php
  	// get all posts in descending date order
  	query_posts('posts_per_page=10000&orderby=date&order=DESC&post_type=post');
	  
	$list_of_posts = array();

	// split entries into blog posts and static pages
	while (have_posts())
	{
		the_post();
		global $post;
		$list_of_posts[] = $post;
	}
			    
  	// show them
  	require_once('archive_show_posts_by_month.inc.php');
	?>
		
    </div>


  </div> <!-- end #all_results -->
	
	
</div> <!-- end #archives -->
</div> <!-- end #content -->

<?php get_sidebar(); ?>
		
<?php get_footer(); ?>
