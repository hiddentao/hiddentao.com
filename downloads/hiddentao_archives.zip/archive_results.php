<?php 
/**
 * This page is used to display a given archives view and is internally 
 * redirected to from archives.php
 */  

if ('' == $qry_tag_name)
{
	require_once('archive.php');
	exit;
}

// get proper tag name
$tag_name = single_tag_title("", false);

get_header(); 
?>

<div id="content">
<a name="content" class="invisible">&para;</a>


<div id="archives">

	<h1 class="title">Archives for tag '<?php echo $tag_name; ?>'</h1>

	<div id="all_results">

<?php if (have_posts()) : ?>

<?php
	$list_of_posts = array();
	$list_of_pages = array();

	// split entries into blog posts and static pages
	while (have_posts()) :
		
		the_post();
		global $post;
		if ('post' === $post->post_type)
		{
			$list_of_posts[] = $post;
		}
		else if ('page' === $post->post_type)
		{
			$list_of_pages[] = $post;
		}
	
	endwhile;	
	
	?>
		<div class="results_pages">
			<p class="description">
				All pages tagged <strong>'<?php echo $tag_name; ?>'</strong>:
			</p>
			
			<div class="indented">
	<?php
		require_once('archive_show_pages.inc.php');
	?>
	    	</div>
	    
		</div>
		
		<div class="results_posts">
			<p class="description">
				All blog posts tagged <strong>'<?php echo $tag_name; ?>'</strong>, from newest to oldest:
			</p>
			
			<div class="indented">
			
	<?php
		require_once('archive_show_posts_by_month.inc.php');
	?>
	    	</div>
	
		</div>

<?php else : ?>

		<p class="description">
			No posts tagged <strong>'<?php echo $tag_name; ?>'</strong> were found.
		</p>

<?php endif; ?>

	</div> <!-- end #all_results -->
	
	<p class="back_to_main_archives_link">
		<?php echo TaoUtils::construct_link(SITE_URI.'/archives/', '&laquo; Archives Home', 'Back to main Archives page'); ?>
	</p>
	
	
</div> <!-- end archives -->
</div> <!-- end content -->

<?php get_sidebar(); ?>
		
<?php get_footer(); ?>
