<?php
/**
 * Output the list of blog posts which match the archive query.
 */

if (!isset($list_of_posts))
{
	require_once('archive_results.php');
	return;
}

if (count($list_of_posts) < 1)
{
	echo '<em>No posts found.</em>';
	return;
}

$prev_month_year = '';  // used for grouping by month

foreach ($list_of_posts as $current_post) :
  
  	global $post;
  	$post = $current_post;
  	setup_postdata($post);
  
	$permalink_url = get_permalink();

    // get necessary date components
    list($cur_day, $cur_day_text, $cur_month, $cur_month_name, $cur_year) 
          = explode(' ', get_the_time('d j m F Y'));
    
	// group by month
	$cur_month_year = $cur_month_name . ' ' . $cur_year;
	if ($cur_month_year != $prev_month_year)
	{
		// if this isn't the first month we're showing
		if ('' != $prev_month_year)
			echo '</ul></div>';
    ?>
	  <div class="month">
	    <span class="month_title">
	        <?php echo $cur_month_year; ?>
	    </span>
		<ul class="linklist">
    <?php
    }

	$prev_month_year = $cur_month_year;
  ?>
			<li class="post">
			  <span title="Posted on <?php echo "$cur_day_text $cur_month_year"; ?>"><?php echo $cur_day; ?>: </span> 
				<span>
	        		<a href="<?php echo $permalink_url; ?>" title="<?php echo $myStrings->str_read_fullpost; ?>" rel="bookmark"><?php the_title('',''); ?></a>
	      		</span>
	      		<?php if (comments_open()): ?>
				<span class="meta comments">
	  			(<a href="<?php comments_link(); ?>" 
	  				title="<?php echo $myStrings->str_view_post_feedback; ?>"><?php comments_number(__('0'), __('1'), __('%')); ?></a>)
				</span>
	      		<?php endif; ?>
			</li>
	<?php 
	
endforeach;  

if ('' != $prev_month_year)
	echo '</ul></div>';	
?>
